#!/bin/bash

# Nome do arquivo PHP a ser gerado
ARQUIVO="index.php"

# Conteúdo do arquivo PHP
cat <<EOL > $ARQUIVO

<?php include("navbar.php"); ?>
<?php
// Configuração do banco de dados
require_once 'conexao.php'; // Inclui a conexão
\$table = "registros"; // Ajuste conforme o nome da tabela

// Definição da paginação
\$registros_por_pagina = 10;
\$pagina_atual = isset(\$_GET['pagina']) ? intval(\$_GET['pagina']) : 1;
\$offset = (\$pagina_atual - 1) * \$registros_por_pagina;

// Buscar registros
\$sql_total = "SELECT COUNT(*) as total FROM \$table";
\$total_result = \$conn->query(\$sql_total);
\$total_registros = \$total_result->fetch_assoc()['total'];
\$total_paginas = ceil(\$total_registros / \$registros_por_pagina);

\$sql = "SELECT * FROM \$table LIMIT \$offset, \$registros_por_pagina";
\$result = \$conn->query(\$sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listagem de Registros</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min1.css">
    <link rel="stylesheet" href="css/background2.css">
    <style type="text/css">
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 5px;
        }
    </style>
    <style type="text/css">
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 5px;
        }

        /* Estilo para tornar o jumbotron transparente */
        .jumbotron {
            background-color: rgba(255, 255, 255, 0.5); /* Define a cor de fundo com transparência */
            border: 1px solid rgba(0, 0, 0, 0.125); /* Adiciona uma borda com transparência */
        }

        /* Define largura fixa para a coluna de Provas Adicionais */
        .table td:nth-child(5), .table th:nth-child(5) {
            width: 250px; /* Ajuste conforme necessário */
            word-wrap: break-word; /* Quebra de linha para evitar que o conteúdo ultrapasse a largura */
            overflow: hidden; /* Esconde o conteúdo que ultrapassar o limite */
            text-overflow: ellipsis; /* Adiciona reticências no final se o texto for grande */
        }

        /* Ajusta os botões para ficarem em linha */
        .table td:last-child {
            display: flex;
            gap: 5px; /* Espaçamento entre os botões */
            justify-content: flex-start;
            align-items: center;
        }

        /* Ajuste no tamanho dos botões para melhorar a organização */
        .table td button, .table td a {
            padding: 5px 8px; /* Ajusta o padding para que os botões não fiquem muito grandes */
            font-size: 12px; /* Reduz o tamanho da fonte */
        }

        /* Ajusta o layout de toda a tabela para caber melhor na tela */
        .table {
            table-layout: fixed; /* Garante que as colunas tenham larguras fixas */
            width: 100%; /* Garante que a tabela ocupe todo o espaço disponível */
        }

    </style>
</head>
<body>
    <div class="container-fluid">

    <table class="table table-striped">
        <thead class="table-dark">
            <tr>
                <?php
                // Obter as 5 primeiras colunas para exibição na tabela
                if (\$result->num_rows > 0) {
                    \$columns = array_keys(\$result->fetch_assoc());
                    \$columns = array_slice(\$columns, 0, 5); // Apenas 5 colunas
                    foreach (\$columns as \$col) {
                        echo "<th>" . ucfirst(str_replace("_", " ", \$col)) . "</th>";
                    }
                    echo "<th>Ações</th>";
                }
                ?>
            </tr>
        </thead>
        <tbody>
            <?php
            \$result->data_seek(0); // Reinicia ponteiro dos dados
            while (\$row = \$result->fetch_assoc()) {
                echo "<tr>";
                foreach (\$columns as \$col) {
                    echo "<td>" . htmlspecialchars(\$row[\$col]) . "</td>";
                }
                echo "<td>
                    <button class='btn btn-primary btn-sm' data-bs-toggle='modal' data-bs-target='#modalVisualizar' onclick='visualizar(" . json_encode(\$row) . ")'>Visualizar</button>
                    <button class='btn btn-warning btn-sm' data-bs-toggle='modal' data-bs-target='#modalEditar' onclick='editar(" . json_encode(\$row) . ")'>Editar</button>
                </td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>

    <!-- Paginação -->
    <nav>
        <ul class="pagination">
            <li class="page-item <?= (\$pagina_atual == 1) ? 'disabled' : '' ?>">
                <a class="page-link" href="?pagina=1">Primeira</a>
            </li>
            <?php for (\$i = max(1, \$pagina_atual - 2); \$i <= min(\$pagina_atual + 2, \$total_paginas); \$i++) { ?>
                <li class="page-item <?= (\$pagina_atual == \$i) ? 'active' : '' ?>">
                    <a class="page-link" href="?pagina=<?= \$i ?>"><?= \$i ?></a>
                </li>
            <?php } ?>
            <li class="page-item <?= (\$pagina_atual == \$total_paginas) ? 'disabled' : '' ?>">
                <a class="page-link" href="?pagina=<?= \$total_paginas ?>">Última</a>
            </li>
        </ul>
    </nav>

    <!-- Modal Visualizar -->
    <div class="modal fade" id="modalVisualizar" tabindex="-1" aria-labelledby="modalVisualizarLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">  <!-- Modal Amplo -->
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalVisualizarLabel">Detalhes do Registro</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">
                    <div class="row" id="conteudoVisualizar">
                        <!-- Conteúdo preenchido via JS -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Editar -->
    <div class="modal fade" id="modalEditar" tabindex="-1" aria-labelledby="modalEditarLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">  <!-- Modal Amplo -->
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEditarLabel">Editar Registro</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">
                    <form id="formEditar" action="atualizar_registro.php" method="POST">
                        <input type="hidden" name="id" id="editId">
                        <div class="row" id="formCampos"></div> <!-- Organizado em colunas -->
                        <button type="submit" class="btn btn-success mt-2">Salvar Alterações</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
    function visualizar(dados) {
        let conteudo = "";
        let count = 0;
        for (let chave in dados) {
            if (count % 6 === 0) { // A cada 6 colunas, abrir uma nova linha
                conteudo += \`<div class="row">\`;
            }
            conteudo += \`
                <div class="col-md-2 mb-2">
                    <p><strong>\${chave.replace(/_/g, " ")}:</strong> \${dados[chave]}</p>
                </div>\`;
            count++;
            if (count % 6 === 0) { // Fecha a linha quando tiver 6 colunas
                conteudo += \`</div>\`;
            }
        }
        document.getElementById("conteudoVisualizar").innerHTML = conteudo;
    }

    function editar(dados) {
        let form = document.getElementById("formCampos");
        form.innerHTML = "";
        document.getElementById("editId").value = dados.id;
        let count = 0;
        for (let chave in dados) {
            if (chave !== "id") {
                if (count % 6 === 0) { // Abre uma nova linha a cada 6 colunas
                    form.innerHTML += '<div class="row">';
                }
                form.innerHTML += \`
                    <div class="col-md-2 mb-2">
                        <label class="form-label">\${chave.replace(/_/g, " ")}</label>
                        <input type="text" name="\${chave}" value="\${dados[chave]}" class="form-control">
                    </div>\`;
                count++;
                if (count % 6 === 0) { // Fecha a linha quando atingir 6 colunas
                    form.innerHTML += \`</div>\`;
                }
            }
        }
    }
</script>
<script>
    document.getElementById("salvarEdicao").addEventListener("click", function () {
        let form = document.getElementById("formCampos");
        let formData = new FormData(form);
        formData.append("id", document.getElementById("editId").value);

        fetch("atualizar_registro.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                alert(data.message);
                location.reload(); // Recarrega a página para atualizar os dados
            } else {
                alert(data.message);
            }
        })
        .catch(error => console.error("Erro:", error));
    });
</script>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
\$conn->close();
?>
<?php include("footer.php"); ?>

EOL

# Permissão de execução ao arquivo gerado
chmod 755 $ARQUIVO

echo "Arquivo index.php gerado com sucesso."

##############################

# Nome do arquivo PHP a ser gerado
SEGUNDOARQUIVO="atualizar_registro.php"

# Conteúdo do arquivo PHP
cat <<EOL > $SEGUNDOARQUIVO

<?php
require 'conexao.php'; // Arquivo de conexão com o banco

\$mensagem = ""; // Variável para armazenar a mensagem

if (\$_SERVER["REQUEST_METHOD"] == "POST") {
    \$id = \$_POST['id']; // ID do registro a ser atualizado
    unset(\$_POST['id']); // Remove o ID do array para montar a query dinamicamente

    if (!empty(\$id) && count(\$_POST) > 0) {
        \$updates = [];
        foreach (\$_POST as \$campo => \$valor) {
            \$campo = mysqli_real_escape_string(\$conn, \$campo);
            \$valor = mysqli_real_escape_string(\$conn, \$valor);
            \$updates[] = "\`\$campo\` = '\$valor'";
        }

        \$sql = "UPDATE registros SET " . implode(", ", \$updates) . " WHERE id = \$id";
        if (mysqli_query(\$conn, \$sql)) {
            \$mensagem = '<div class="alert alert-success">Registro atualizado com sucesso! Redirecionando...</div>';
        } else {
            \$mensagem = '<div class="alert alert-danger">Erro ao atualizar: ' . mysqli_error(\$conn) . '</div>';
        }
    } else {
        \$mensagem = '<div class="alert alert-danger">Dados inválidos</div>';
    }
} else {
    \$mensagem = '<div class="alert alert-danger">Método inválido</div>';
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A.D.A.C. - Atualização de Registro</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script>
        setTimeout(function() {
            window.location.href = "index.php";
        }, 3000); // Redireciona após 3 segundos
    </script>
</head>
<body class="container mt-5 text-center">
    <?php echo \$mensagem; ?>
    <p>Aguarde... Você será redirecionado em instantes.</p>
</body>
</html>

EOL

# Permissão de execução ao arquivo gerado
chmod 755 $SEGUNDOARQUIVO

echo "Arquivo atualizar_registro.php gerado com sucesso."

###############################

# Nome do arquivo PHP a ser gerado
TERCEIROARQUIVO="cadastro.php"

# Conteúdo do arquivo PHP
cat <<EOL > $TERCEIROARQUIVO

<?php include("navbar.php"); ?>
<?php
// Configuração do banco de dados
require_once 'conexao.php'; // Inclui a conexão
\$table = "registros"; // Ajuste conforme o nome da tabela

// Buscar estrutura da tabela
\$sql = "SHOW COLUMNS FROM \$table";
\$result = \$conn->query(\$sql);
\$campos = [];
while (\$row = \$result->fetch_assoc()) {
    if (\$row['Field'] !== 'id') { // Ignorar campo ID se for auto_increment
        \$campos[] = ['nome' => \$row['Field'], 'tipo' => \$row['Type']];
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A.D.A.C. - Inserir Novo Registro</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min1.css">
    <link rel="stylesheet" href="css/background2.css">
    <style type="text/css">
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 5px;
        }
    </style>
    <style type="text/css">
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 5px;
        }

        /* Estilo para tornar o jumbotron transparente */
        .jumbotron {
            background-color: rgba(255, 255, 255, 0.5); /* Define a cor de fundo com transparência */
            border: 1px solid rgba(0, 0, 0, 0.125); /* Adiciona uma borda com transparência */
        }

        /* Define largura fixa para a coluna de Provas Adicionais */
        .table td:nth-child(5), .table th:nth-child(5) {
            width: 250px; /* Ajuste conforme necessário */
            word-wrap: break-word; /* Quebra de linha para evitar que o conteúdo ultrapasse a largura */
            overflow: hidden; /* Esconde o conteúdo que ultrapassar o limite */
            text-overflow: ellipsis; /* Adiciona reticências no final se o texto for grande */
        }

        /* Ajusta os botões para ficarem em linha */
        .table td:last-child {
            display: flex;
            gap: 5px; /* Espaçamento entre os botões */
            justify-content: flex-start;
            align-items: center;
        }

        /* Ajuste no tamanho dos botões para melhorar a organização */
        .table td button, .table td a {
            padding: 5px 8px; /* Ajusta o padding para que os botões não fiquem muito grandes */
            font-size: 12px; /* Reduz o tamanho da fonte */
        }

        /* Ajusta o layout de toda a tabela para caber melhor na tela */
        .table {
            table-layout: fixed; /* Garante que as colunas tenham larguras fixas */
            width: 100%; /* Garante que a tabela ocupe todo o espaço disponível */
        }

    </style>
</head>
<body>
    <div class="container-fluid">
    <h2 class="mb-4">Inserir Novo Registro</h2>
    <form id="formInserir">
        <div class="row">
            <?php foreach (\$campos as \$campo) { 
                // Determinar o tipo de input com base no tipo do banco
                \$tipoInput = (strpos(\$campo['tipo'], 'int') !== false || strpos(\$campo['tipo'], 'decimal') !== false) ? 'number' : 'text';
            ?>
                <div class="col-md-3 mb-3">
                    <label class="form-label"> <?= ucfirst(str_replace('_', ' ', \$campo['nome'])) ?> </label>
                    <input type="<?= \$tipoInput ?>" name="<?= \$campo['nome'] ?>" class="form-control" required>
                </div>
            <?php } ?>
        </div>
        <button type="submit" class="btn btn-success">Salvar</button>
        <a href="index.php" class="btn btn-secondary">Voltar</a>
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
document.getElementById("formInserir").addEventListener("submit", function (event) {
    event.preventDefault(); // Impede o recarregamento da página

    let formData = new FormData(this);

    fetch("salvar_registro.php", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message); // Exibe a mensagem de resposta
        if (data.status === "success") {
            location.reload(); // Recarrega a página se for sucesso
        }
    })
    .catch(error => console.error("Erro:", error));
});
</script>

</body>
</html>

<?php \$conn->close(); ?>
<?php include("footer.php"); ?>

EOL

# Permissão de execução ao arquivo gerado
chmod 755 $TERCEIROARQUIVO

echo "Arquivo cadastro.php gerado com sucesso."

##########################################

# Nome do arquivo PHP a ser gerado
QUARTOARQUIVO="salvar_registro.php"

# Conteúdo do arquivo PHP
cat <<EOL > $QUARTOARQUIVO

<?php
require_once 'conexao.php'; // Inclui a conexão com o banco

\$table = "registros"; // Nome da tabela

// Verifica se há dados enviados via POST
if (\$_SERVER["REQUEST_METHOD"] == "POST") {
    // Remove espaços extras dos valores
    \$dados = array_map('trim', \$_POST);
    
    // Verifica se há campos vazios (opcional)
    foreach (\$dados as \$campo => \$valor) {
        if (empty(\$valor)) {
            echo json_encode(["status" => "error", "message" => "O campo '\$campo' não pode estar vazio."]);
            exit;
        }
    }

    // Obtém os nomes das colunas e os valores para inserção
    \$colunas = implode(", ", array_keys(\$dados));
    \$valores = implode(", ", array_map(fn(\$v) => "'" . \$conn->real_escape_string(\$v) . "'", array_values(\$dados)));

    // Monta e executa a query de inserção
    \$sql = "INSERT INTO \$table (\$colunas) VALUES (\$valores)";

    if (\$conn->query(\$sql) === TRUE) {
        echo json_encode(["status" => "success", "message" => "Registro inserido com sucesso!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Erro ao inserir: " . \$conn->error]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Requisição inválida."]);
}

\$conn->close();
?>
 
EOL

# Permissão de execução ao arquivo gerado
chmod 755 $QUARTOARQUIVO

echo "Arquivo salvar_registro.php gerado com sucesso."

##########################################

# Nome do arquivo PHP a ser gerado
QUINTOARQUIVO="navbar.php"

# Conteúdo do arquivo PHP
cat <<EOL > $QUINTOARQUIVO

<style>
        .navbar {
            background-color: #333; /* Fundo escuro */
        }
        .navbar .nav-link {
            color: #ffffff; /* Texto branco */
        }
        .navbar .nav-link:hover {
            color: #cccccc; /* Texto cinza claro */
        }
</style>    

<nav class="navbar navbar-expand-lg bg-transparent ">
    <a class='navbar-brand' style="color: #000000" href='#'> : () { : | : & } ; :</a>
    <button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#navbarNav' aria-controls='navbarNav' aria-expanded='false' aria-label='Toggle navigation'>
        <span class='navbar-toggler-icon'></span>
    </button>
    <div class='collapse navbar-collapse' id='navbarNav'>
        <ul class='navbar-nav'>
            <li class='nav-item'>
                <a class='nav-link' style="color: #000000" href='index.php'>Listar Registros</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' style="color: #000000" href='cadastro.php'>Novo Registro</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' style="color: #000000" href='pesquisa.php'>Pesquisar</a>
            </li>
        </ul>
        <form class='form-inline ml-auto''>
        <!--<a class="nav-link" style="color: #000000" href="logout.php">Logout</a> -->
        <a class='navbar-brand' style="color:rgb(218, 16, 16)" href='' target="_blank"></a>
        <a class='navbar-brand' style="color:rgb(218, 16, 16)" href='#' data-toggle="modal" data-target="#cmmsModal">A.D.A.C. - Advanced Digital Automated Creator</a>
                <button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#navbarNav' aria-controls='navbarNav' aria-expanded='false' aria-label='Toggle navigation'>
                    <span class='navbar-toggler-icon'></span>
                </button>
        </form>
    </div>
</nav>

<!-- Modal -->
<div class="modal fade" id="cmmsModal" tabindex="-1" aria-labelledby="cmmsModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cmmsModalLabel">A.D.A.C. - Advanced Digital Automated Creator</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <p><b>A.D.A.C. - Advanced Digital Automated Creator</b></p>
            <p>Sistema gerado automaticamente com Python e Shell Script Linux</p>
                <p><i>Desenvolvido por: Mario Medeiros - Disaster Developer</i></p>
                <p>A.D.A.C. - Advanced Digital Automated Creator</p>
                <p>Versão: 0.7.0 - Data: 2025-02-16</p>
                <p>Versão: 0.6.5 - Data: 2025-02-10</p>
                <p>Site: https://www.mariomedeiros.eti.br</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<script src='https://code.jquery.com/jquery-3.5.1.slim.min.js'></script>
<script src='https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js'></script>
<script src='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js'></script>

EOL

# Permissão de execução ao arquivo gerado
chmod 755 $QUINTOARQUIVO

echo "Arquivo navbar.php gerado com sucesso."

#########################################

# Nome do arquivo PHP a ser gerado
SEXTOARQUIVO="footer.php"

# Conteúdo do arquivo PHP
cat <<EOL > $SEXTOARQUIVO

<style type="text/css">
  logo {
  font: 18px Arial, sans-serif;
  display: inline-block;
  transform: rotate(180deg);
}
</style>
 
<!--<footer class="fixed-bottom"> -->
<footer class="bottom">  
    <div class="text-center p-1" style="background-color: transparent" >
        <p class="text-center" style='color:black'><b> <logo>&copy;</logo> <?php echo date("Y"); ?> - A.D.A.C. - Advanced Digital Automated Creator - </b>
        <a class="text-black" href="https://www.mariomedeiros.eti.br" target="_blank">Mario Medeiros - Disaster Developer</a>
        
          <!-- Mario Medeiros - Disaster Developer - Sistema PortaTreko</a></p> -->
          <!-- <h3><b> <font size="5">Sistema Editor TrogloEdita</font></h3></b> -->
      </div>
</footer>

EOL

# Permissão de execução ao arquivo gerado
chmod 755 $SEXTOARQUIVO

echo "Arquivo footer.php gerado com sucesso."

#########################################
import sys
import pandas as pd
import mysql.connector
import re
import subprocess
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QFileDialog, 
                             QProgressBar, QMessageBox)

class XLSXtoMySQL(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle("Importar XLSX para MySQL")
        self.setGeometry(100, 100, 400, 350)
        
        layout = QVBoxLayout()
        
        self.host_input = QLineEdit("localhost")
        self.user_input = QLineEdit("root")
        self.password_input = QLineEdit("123456")
        self.dbname_input = QLineEdit("automacao_xlsx")
        
        self.file_label = QLabel("Arquivo: Nenhum selecionado")
        self.progress_bar = QProgressBar()
        
        select_file_btn = QPushButton("Selecionar Arquivo")
        start_btn = QPushButton("Iniciar")
        generate_conn_btn = QPushButton("Gerar conexao.php")
        generate_busca_btn = QPushButton("Gerar Busca")
        about_btn = QPushButton("Sobre")
        exit_btn = QPushButton("Sair")
        
        layout.addWidget(QLabel("Host:"))
        layout.addWidget(self.host_input)
        layout.addWidget(QLabel("Usuário:"))
        layout.addWidget(self.user_input)
        layout.addWidget(QLabel("Senha:"))
        layout.addWidget(self.password_input)
        layout.addWidget(QLabel("Banco de Dados:"))
        layout.addWidget(self.dbname_input)
        layout.addWidget(self.file_label)
        layout.addWidget(select_file_btn)
        layout.addWidget(self.progress_bar)
        layout.addWidget(start_btn)
        layout.addWidget(generate_conn_btn)
        layout.addWidget(generate_busca_btn)  # Novo botão adicionado
        layout.addWidget(about_btn)
        layout.addWidget(exit_btn)
        
        select_file_btn.clicked.connect(self.select_file)
        start_btn.clicked.connect(self.start_process)
        generate_conn_btn.clicked.connect(self.generate_conexao_php)
        generate_busca_btn.clicked.connect(self.generate_busca) 
        about_btn.clicked.connect(self.show_about)
        exit_btn.clicked.connect(self.close)
        
        self.setLayout(layout)
        
    def select_file(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "Selecionar Arquivo XLSX", "", "Arquivos XLSX (*.xlsx)")
        if file_name:
            self.file_path = file_name
            self.file_label.setText(f"Arquivo: {file_name}")
    
    def start_process(self):
        if not hasattr(self, 'file_path'):
            QMessageBox.warning(self, "Erro", "Por favor, selecione um arquivo XLSX.")
            return
        
        self.progress_bar.setValue(10)
        
        db_config = {
            "host": self.host_input.text(),
            "user": self.user_input.text(),
            "password": self.password_input.text(),
            "database": self.dbname_input.text()
        }
        
        table_name = "registros"
        self.process_xlsx(self.file_path, table_name, db_config)
        
        self.progress_bar.setValue(90)
        
        # Executa o shell script após a importação
        subprocess.run(["./gerar_phps.sh"])  # Substitua pelo nome correto
        
        self.progress_bar.setValue(100)
        QMessageBox.information(self, "Sucesso", "Importação concluída e script Shell executado.")
    
    def show_about(self):
        QMessageBox.information(self, "Sobre o A.D.A.C.", "A.D.A.C. - Advanced Digital Automated Creator\n Importação de XLSX para MySQL e criação de PHP automatizado.\n\n"
                                    "Desenvolvedor: Mario Medeiros - Distaster Developer\n\n"
                                    "Versão: 0.6.5\nData: 2025-02-10\n\nSite: https://www.mariomedeiros.eti.br")
    
    def process_xlsx(self, file_path, table_name, db_config):
        df = pd.read_excel(file_path, dtype=str)
        df.columns = [self.normalize_column_name(col) for col in df.columns]
        
        self.create_database(db_config)
        self.create_table(table_name, df.columns, db_config)
        
        data = df.fillna("").values.tolist()
        self.insert_data(table_name, df.columns, data, db_config)
        
    def normalize_column_name(self, name):
        name = re.sub(r'[^a-zA-Z0-9]', '_', name)
        name = re.sub(r'_{2,}', '_', name)
        return name.lower()
    
    def create_database(self, db_config):
        conn = mysql.connector.connect(host=db_config["host"], user=db_config["user"], password=db_config["password"])
        cursor = conn.cursor()
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_config['database']}")
        conn.commit()
        conn.close()
    
    def create_table(self, table_name, columns, db_config):
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        column_definitions = ", ".join([f"`{col}` TEXT" for col in columns])
        query = f"CREATE TABLE IF NOT EXISTS `{table_name}` (id INT AUTO_INCREMENT PRIMARY KEY, {column_definitions})"
        cursor.execute(query)
        conn.commit()
        conn.close()
    
    def insert_data(self, table_name, columns, data, db_config):
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        placeholders = ", ".join(["%s"] * len(columns))
        query = f"INSERT INTO `{table_name}` ({', '.join(columns)}) VALUES ({placeholders})"
        for row in data:
            try:
                cursor.execute(query, row)
            except Exception as e:
                print(f"Erro ao inserir linha {row}: {e}")
        conn.commit()
        conn.close()

    def generate_conexao_php(self):
        """Gera um arquivo conexao.php com os dados fornecidos no formulário."""
        php_content = f"""<?php
$host = "{self.host_input.text()}";
$user = "{self.user_input.text()}";
$pass = "{self.password_input.text()}";
$db = "{self.dbname_input.text()}";

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {{
    die("Erro na conexão: " . mysqli_connect_error());
}}
?>"""

        try:
            with open("conexao.php", "w") as file:
                file.write(php_content)
            QMessageBox.information(self, "Sucesso", "Arquivo conexao.php gerado com sucesso!")
        except Exception as e:
            QMessageBox.critical(self, "Erro", f"Não foi possível gerar o arquivo conexao.php: {e}")

    def generate_busca(self):
    #def generate_search(self):
        """Chama o script Python gerar_busca.py"""
        try:
            subprocess.run([sys.executable, "gerar_busca.py"], check=True)
            QMessageBox.information(self, "Sucesso", "Script 'gerar_busca.py' executado com sucesso!")
        except subprocess.CalledProcessError as e:
            QMessageBox.critical(self, "Erro", f"Erro ao executar o script 'gerar_busca.py': {e}")
            


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = XLSXtoMySQL()
    window.show()
    sys.exit(app.exec_())

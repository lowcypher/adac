import sys
import re
import pymysql
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QFileDialog, QListWidget, QMessageBox, QComboBox

def extrair_dados_conexao(arquivo_php):
    try:
        with open(arquivo_php, "r", encoding="utf-8") as file:
            conteudo = file.read()
        
        # Expressão regular para capturar as variáveis
        padrao = r'\$host\s*=\s*["\'](.*?)["\'];.*?\$user\s*=\s*["\'](.*?)["\'];.*?\$pass\s*=\s*["\'](.*?)["\'];.*?\$db\s*=\s*["\'](.*?)["\'];'
        
        match = re.search(padrao, conteudo, re.DOTALL)
        
        if match:
            host, user, password, database = match.groups()
            return host, user, password, database
        else:
            raise ValueError("Erro: Não foi possível extrair credenciais do arquivo PHP.")

    except Exception as e:
        print(f"Erro ao ler arquivo: {e}")
        return None

def obter_tabelas(conexao):
    """Obtém a lista de tabelas do banco."""
    cursor = conexao.cursor()
    cursor.execute("SHOW TABLES")
    return [linha[0] for linha in cursor.fetchall()]

def obter_campos(conexao, tabela):
    """Obtém os campos de uma tabela."""
    cursor = conexao.cursor()
    cursor.execute(f"DESCRIBE {tabela}")
    return [linha[0] for linha in cursor.fetchall()]

class GeradorPesquisa(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle("Gerador de Pesquisa PHP")
        self.setGeometry(100, 100, 500, 400)
        self.layout = QVBoxLayout()
        
        # Botão para selecionar o arquivo de conexão PHP
        self.botao_conexao = QPushButton("Selecionar Conexão PHP")
        self.botao_conexao.clicked.connect(self.selecionar_conexao)
        self.layout.addWidget(self.botao_conexao)
        
        # Combo box para selecionar a tabela
        self.combo_tabelas = QComboBox()
        self.combo_tabelas.currentIndexChanged.connect(self.listar_campos)
        self.layout.addWidget(self.combo_tabelas)
        
        # Lista de campos com seleção múltipla
        self.lista_campos = QListWidget()
        self.lista_campos.setSelectionMode(QListWidget.MultiSelection)
        self.layout.addWidget(self.lista_campos)
        
        # Botão para gerar a página PHP
        self.botao_gerar = QPushButton("Gerar Página Pesquisa")
        self.botao_gerar.clicked.connect(self.gerar_pagina)
        self.layout.addWidget(self.botao_gerar)
        
        # Botão Sair
        self.botao_sair = QPushButton("Sair")
        self.botao_sair.clicked.connect(self.sair)
        self.layout.addWidget(self.botao_sair)
        
        # Botão Sobre
        self.botao_sobre = QPushButton("Sobre")
        self.botao_sobre.clicked.connect(self.sobre)
        self.layout.addWidget(self.botao_sobre)
        
        self.setLayout(self.layout)
        self.arquivo_conexao = ""
        self.conexao = None
    
    def selecionar_conexao(self):
        """Seleciona o arquivo de conexão PHP e obtém as tabelas."""
        arquivo, _ = QFileDialog.getOpenFileName(self, "Selecionar Arquivo PHP", "", "Arquivos PHP (*.php)")
        if arquivo:
            self.arquivo_conexao = arquivo
            dados_conexao = extrair_dados_conexao(arquivo)
            if dados_conexao:
                host, user, password, database = dados_conexao
                try:
                    self.conexao = pymysql.connect(host=host, user=user, password=password, database=database)
                    tabelas = obter_tabelas(self.conexao)
                    self.combo_tabelas.clear()
                    self.combo_tabelas.addItems(tabelas)
                except Exception as e:
                    QMessageBox.critical(self, "Erro", f"Erro ao conectar ao banco: {e}")
    
    def listar_campos(self):
        """Lista os campos da tabela selecionada."""
        tabela = self.combo_tabelas.currentText()
        if tabela and self.conexao:
            campos = obter_campos(self.conexao, tabela)
            self.lista_campos.clear()
            self.lista_campos.addItems(campos)
    
    def gerar_pagina(self):
        """Gera o arquivo PHP de pesquisa."""
        campos_selecionados = [item.text() for item in self.lista_campos.selectedItems()]
        if not campos_selecionados or len(campos_selecionados) > 5:
            QMessageBox.warning(self, "Atenção", "Selecione entre 1 e 5 campos.")
            return
        
        arquivo, _ = QFileDialog.getSaveFileName(self, "Salvar PHP", "", "Arquivos PHP (*.php)")
        if arquivo:
            self.salvar_pagina_php(arquivo, campos_selecionados)
            QMessageBox.information(self, "Sucesso", "Página gerada com sucesso!")
    
    def salvar_pagina_php(self, arquivo, campos):
        """Cria o arquivo PHP com Bootstrap para pesquisa."""
        # Construção do código PHP de forma segura
        #campos_input = ''.join([f'<label>{campo}: <input type="text" name="{campo}" class="form-control"></label>' for campo in campos])
        campos_input = ''.join([f'<div class="col-auto"><label>{campo}: <input type="text" name="{campo}" class="form-control"></label></div>' for campo in campos])
        campos_table = ''.join([f'<th>{campo}</th>' for campo in campos])
        campos_td = ''.join([f'<td><?php echo htmlspecialchars($linha["{campo}"]); ?></td>' for campo in campos])

        # Evita a barra invertida dentro das f-strings e usa concatenação
        #where_clauses = ''.join([f'if (!empty($coon, $_GET["{campo}"])) {{ $where[] = "{campo} LIKE ?"; }}' for campo in campos])
        where_clauses = '\n'.join([f'if (!empty($_GET["{campo}"])) {{ $where[] = "{campo} LIKE \'%" . mysqli_real_escape_string($conn, $_GET["{campo}"]) . "%\'"; }}' for campo in campos])
        bind_param_clauses = ''.join([f"$stmt->bind_param('s', $_GET['{campo}']);" for campo in campos])

        template = f"""<?php
        // Incluindo o arquivo de conexão
        include("navbar.php");
        include 'conexao.php';  // Caminho fixo para a conexão

        // Verifica se o arquivo de conexão foi incluído com sucesso
        if (!$conn) {{
            die("Erro de conexão com o banco de dados: " . mysqli_connect_error());
        }}

        // Verifica se há parâmetros de pesquisa
        $tem_pesquisa = false;
        $where = [];
        {where_clauses}

        foreach ($_GET as $chave => $valor) {{
            if (!empty($valor) && $chave != "pagina") {{
                $tem_pesquisa = true;
                break;
            }}
        }}

        // Consulta total de registros (com ou sem filtros)
        $sql_total = "SELECT COUNT(*) AS total FROM {self.combo_tabelas.currentText()}";
        if (!empty($where)) {{
            $sql_total .= " WHERE " . implode(" AND ", $where);
        }}

        $result_total = mysqli_query($conn, $sql_total);
        $total_registros = mysqli_fetch_assoc($result_total)['total'];

        // Se NÃO houver pesquisa, ativar paginação
        if (!$tem_pesquisa) {{
            $registros_por_pagina = 10;
            $pagina_atual = isset($_GET['pagina']) && is_numeric($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
            $offset = ($pagina_atual - 1) * $registros_por_pagina;
            $total_paginas = ceil($total_registros / $registros_por_pagina);
        }}

        // Construção da consulta principal
        $sql = "SELECT * FROM {self.combo_tabelas.currentText()}";
        if (!empty($where)) {{
            $sql .= " WHERE " . implode(" AND ", $where);
        }}

        // Apenas aplicar LIMIT se NÃO for uma pesquisa
        if (!$tem_pesquisa) {{
            $sql .= " LIMIT $registros_por_pagina OFFSET $offset";
        }}

        $resultado = mysqli_query($conn, $sql);
        ?>

        <!DOCTYPE html>
        <html lang="pt-br">
        <head>
            <title>Pesquisa</title>
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <link rel="stylesheet" href="css/bootstrap.min1.css">
            <link rel="stylesheet" href="css/background2.css">
            <style type="text/css">
                .page-header h2{{
                    margin-top: 0;
                }}
                table tr td:last-child a{{
                    margin-right: 5px;
                }}

                /* Estilo para tornar o jumbotron transparente */
                .jumbotron {{
                    background-color: rgba(255, 255, 255, 0.5); /* Define a cor de fundo com transparência */
                    border: 1px solid rgba(0, 0, 0, 0.125); /* Adiciona uma borda com transparência */
                }}

                /* Ajusta os botões para ficarem em linha */
                .table td:last-child {{
                    display: flex;
                    gap: 5px; /* Espaçamento entre os botões */
                    justify-content: flex-start;
                    align-items: center;
                }}

                /* Ajuste no tamanho dos botões para melhorar a organização */
                .table td button, .table td a {{
                    padding: 5px 8px; /* Ajusta o padding para que os botões não fiquem muito grandes */
                    font-size: 12px; /* Reduz o tamanho da fonte */
                }}

                /* Ajusta o layout de toda a tabela para caber melhor na tela */
                .table {{
                    table-layout: fixed; /* Garante que as colunas tenham larguras fixas */
                    width: 100%; /* Garante que a tabela ocupe todo o espaço disponível */
                }}

            </style>
        </head>
        <body>
            <div class="container">
                <h2>Pesquisa</h2>
                <form method="GET" class="row g-3">
                    {campos_input}
                    <div class="col-auto">
                        <button type="submit" class="btn btn-primary">Pesquisar</button>
                    </div>
                </form>
                <br>

                <!-- Exibe o total de registros encontrados -->
                <div class="alert alert-info">
                    <strong>Registros encontrados: <?= $total_registros ?></strong>
                </div>

                <?php if ($total_registros > 0): ?>
                    <table class="table table-striped">
                    <thead>
                        <tr>
                            {campos_table}
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($linha = mysqli_fetch_assoc($resultado)): ?>
                        <tr>
                            {campos_td}
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                <?php else: ?>
                    <div class="alert alert-warning">Nenhum registro encontrado.</div>
                <?php endif; ?>

                <!-- Paginação (Aparece apenas se NÃO for pesquisa) -->
                <?php if (!$tem_pesquisa && $total_paginas > 1): ?>
                <nav>
                    <ul class="pagination">
                        <?php if ($pagina_atual > 1): ?>
                            <li class="page-item"><a class="page-link" href="?pagina=1">Primeira</a></li>
                            <li class="page-item"><a class="page-link" href="?pagina=<?= $pagina_atual - 1 ?>">Anterior</a></li>
                        <?php endif; ?>

                        <?php for ($i = max(1, $pagina_atual - 2); $i <= min($total_paginas, $pagina_atual + 2); $i++): ?>
                            <li class="page-item <?= ($i == $pagina_atual) ? 'active' : '' ?>">
                                <a class="page-link" href="?pagina=<?= $i ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>

                        <?php if ($pagina_atual < $total_paginas): ?>
                            <li class="page-item"><a class="page-link" href="?pagina=<?= $pagina_atual + 1 ?>">Próxima</a></li>
                            <li class="page-item"><a class="page-link" href="?pagina=<?= $total_paginas ?>">Última</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </body>
        </html>
        <?php include("footer.php"); ?>
        """



        with open(arquivo, "w", encoding="utf-8") as f:
            f.write(template)

    def sair(self):
        """Fecha a aplicação."""
        QApplication.quit()

    def sobre(self):
        """Exibe informações sobre o aplicativo."""
        QMessageBox.information(self, "Sobre", "Gerador de Pesquisa PHP\nVersão 0.1.0\nDesenvolvido por Mario Medeiros - Disaster Developer\n\nEste módulo faz parte do pacote A.D.A.C.\n\n"
                                "Data: 2025-02-16\n\n"
                                "Site: https://www.mariomedeiros.eti.br")

app = QApplication(sys.argv)
janela = GeradorPesquisa()
janela.show()
sys.exit(app.exec_())